from flask import Flask
from flask import session
from flask import render_template
from flask import request
from flask import url_for
from flask import flash, redirect
import models as dbHandler
from functools import wraps


app = Flask(__name__)
app.secret_key = 'MKhJHJH798798kjhkjhkjGHh'

@app.route('/')
def index():
   if 'username' in session:
      return render_template("index.html", logged_in = True,  username=session['username'])
   else:
     return render_template("index.html", logged_in = False, username=None)
 

@app.route('/login', methods=['POST', 'GET'])
def login():
  if request.method=='POST':
     # POST method indicates initial login form has been filled and submitted
      next = request.values.get('next')
      print "password looks like", request.values.get('password')
      if (dbHandler.authenticate(request)):
         # User is successfully authenticated
         if not next:
            #login authentication by itself
            return render_template("result.html", message = session['username']+" has successfully logged in!",rows=[], length=0)
         else:
            #login authentication was called to access some confidential data
            print  "On redirect - next=", next
            return redirect(next)
      else:
	 # User has failed authentication
         return render_template("result.html", message="User has failed authentication!",rows=[], length=0)
  else:
     # GET method indicates request for initial login page
     if ('username' in session):
         # if some user is already logged in current session, then wait for logout first
        return render_template("result.html", message=session['username'] + " is already logged in. Log out to proceed.",rows=[], length=0)
     else:
        # login form is waiting to be filled
        return render_template('login.html')

   
@app.route('/register', methods=['POST', 'GET'])
def register():
	if request.method=='POST':
		return render_template("result.html", message = dbHandler.insertUser(request),rows=[], length=0);
	else:
		return render_template('register.html')

             
@app.route('/logout', methods=['POST', 'GET'])
def logout():
    if 'username' in session:
        name = session.pop('username')
        return render_template("result.html", message=name +" has logged out Successfully.",rows=[], length=0)
    return render_template("result.html", message="You are already logged out.",rows=[], length=0)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' in session:
           return f(*args, **kwargs)
        else:
           print "Can not  access secret_page without logging in"
           print url_for('login', next = request.path)
           return redirect(url_for('login', next = request.path))
                           
    return decorated_function

@app.route('/secret_page')
@login_required
def secret_page():
    if 'username' in session:
        rows, msg = dbHandler.retrieveUsers(session['username'])
        return render_template("result.html", message=msg, rows=rows, length= len(rows))
    else:
      return render_template("result.html", message="You can see this confidential page only if you are logged in!!!!", rows=[], length=0)
  


if __name__ == '__main__':
#    app.run(debug=True, host='127.0.0.1')
    app.run(debug=False, host='127.0.0.1',port=5001, ssl_context=('cert.pem', 'key.pem'))
   

