PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE users (
    id integer primary key autoincrement,
    username text not null,
    password text not null,
    age text,
    gender text ,
    interest text 
);
INSERT INTO "users" VALUES(1,'test','$5$rounds=535000$zU70v.DbFbGhVp3t$65rzpBqTkVPURAI3hsnudnBXDCpxXE1Hl09rBOsSUM/','12','Female','Fiction');
INSERT INTO "users" VALUES(2,'test1','$5$rounds=535000$aVKjCwWqhMquxF4e$RE8paxhBF3mHmNBTe6OstDQiTdiZRpm6S8s.9TrviAA','13','Female','Comics');
INSERT INTO "users" VALUES(3,'test2','$5$rounds=535000$T9KrH6OWRrQs5u4P$RZXXQI4KBW7BVY4Vf9hSCZLa1HDFn0iiR2Ok4TeedVC','45','Male','Sports');
INSERT INTO "users" VALUES(4,'test3','$5$rounds=535000$YLA5f3zuKEO2ZW3I$CXYRr6GKZgU9cgUg09lpZzWnW5ioozUesx138ebSqL6','43','Female','Fiction');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('users',4);
COMMIT;
