FOR HTTPS
###################################
1.sudo pip install pyopenssl
2. openssl req -x509 -newkey rsa:4096 -nodes -out cert.pem -keyout
key.pem -days 365

3. app.run(ssl_context=('cert.pem', 'key.pem'))
4. view certificates/authorities/import/ -- select cert.pem
5. if still get connection error, go to advanced, exception, drop
exception on certificate validation
6. make sure https://... is used in urls not http://...


FOR DEMOS
################################
register user 'test' with password 'foo'
or use existing output.sql to build your database
now do sql injection through username field - inject part of sql
query there. Use Valid password 'foo' for successful login
Now goto secret_page and see the entire table (all users instead of
single user)
------------------------------
username: 'OR 1=1 OR '
password: foo
--------------------------------
username: ' or 1=1;--	
password: foo

--------------------------
Username: foo' Union SELECT * FROM users--'
password: foo
------------------------
Username: foo' Union SELECT * FROM users order by 2--'
password: foo

----------------- FIX (use prepared statements) ------------------
    sqlQuery = "select * from users where username ='" + username + "' and password ='" + password + "';"
       print "sqlQuery=", sqlQuery
       cursor.execute(sqlQuery)
    else:
       sqlQuery = "select * from users where username = ? and password = ?";

