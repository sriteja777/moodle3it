PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE users (
    id integer primary key autoincrement,
    username text not null,
    password text not null,
    age text,
    gender text ,
    interest text 
);
INSERT INTO "users" VALUES(1,'test','$5$rounds=535000$ttsg7Z6Fk6BL.kCy$WH0ERWAF5dGIbRofaBo1ERwCQFhpBOuYG9wWF3H9Jv5','12','Male','Computers');
INSERT INTO "users" VALUES(2,'admin','$5$rounds=535000$sJmbRvhCOrV99ZSk$bEF/oewuJGaQOkTR.kEMT5jWCG6YA6gAVmSNlr7lSY.','100','Male','Computers');
INSERT INTO "users" VALUES(3,'test1','$5$rounds=535000$ocDsLchUnIl6maks$hoPQS8dwGtsunvBtuFTfNYlanVYFs5b2XEQVJyxdtd6','<h2 style=color:blue;>hello</h2>','Male','Computers');
INSERT INTO "users" VALUES(4,'<h1 style=color:red;>hello</h1>','$5$rounds=535000$Mfo2QFsvV4.QS/g8$.wynrx1tYL3Suk0W5JDw.WJikP/ILiMaGzWKRN.QdO1','12','Male','Computers');
INSERT INTO "users" VALUES(5,'<script>alert(document.cookie);</script>','$5$rounds=535000$2XLb5mJhGpKDsAA9$h0rCy4QdZpaYgp55Kw4GkDl9hbl15pTtZPJfJ.CwMU.','12','Male','Computers');
INSERT INTO "users" VALUES(6,'<script>document.write("hello world")</script>','$5$rounds=535000$joQqmSSSTE/eL5tM$6ej7l2Ey/SUvmmBgeaY1fedIJ4v3uCXTbpxGsksKYS7','12','Male','Computers');
INSERT INTO "users" VALUES(7,'<a href="https://www.w3schools.com/html/">Visit our HTML tutorial</a>','$5$rounds=535000$Gz9BkOZEF/pZ1yg.$hTsL8nZO3AYY4MMkiPjxlGmUJw/fPyHvffsjV1KCmT0','12','Male','Computers');
INSERT INTO "users" VALUES(8,'<img src="https://static.pexels.com/photos/62681/lotus-flower-nymphaea-caerulea-aquatic-plant-62681.jpeg" alt="violet lotus, height="200" width="200"">"','$5$rounds=535000$k8DWOQHDjV9SV4.h$XgU14WgHMjT343rShShwHmAYjG5.hFlIxL8XKvsG2UA','12','Male','Computers');
INSERT INTO "users" VALUES(9,'<iframe width="200" height="200" src="https://www.youtube.com/embed/4C-gxOE0j7s" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>','$5$rounds=535000$lyI/4mkk6sGUPg.C$2BaZ.mmVRaJgFVv/689VMzQA.cu3RIXI2Nfr7HdOmo/','12','Male','Computers');
INSERT INTO "users" VALUES(10,'<script>alert(document.location);</script>','$5$rounds=535000$lyI/4mkk6sGUPg.C$2BaZ.mmVRaJgFVv/689VMzQA.cu3RIXI2Nfr7HdOmo/','12','Male','Computers');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('users',15);
COMMIT;
