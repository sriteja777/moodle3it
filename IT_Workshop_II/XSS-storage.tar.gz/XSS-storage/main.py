from flask import Flask
from flask import session
from flask import render_template
from flask import request
from flask import url_for
from flask import flash, redirect
import models as dbHandler
from functools import wraps



app = Flask(__name__)
app.secret_key = 'MKhJHJH798798kjhkjhkjGHh'

@app.route('/')
def index():
   if 'username' in session:
      return render_template("index.html", logged_in = True,  username=session['username'])
   else:
     return render_template("index.html", logged_in = False, username=None)
 

@app.route('/login', methods=['POST', 'GET'])
def login():
  if request.method=='POST':
     # POST method indicates initial login form has been filled and submitted
      next = request.values.get('next')
      print "password looks like", request.values.get('password')
      if (dbHandler.authenticate(request)):
         # User is successfully authenticated
         if not next:
            #login authentication by itself
            return render_template("result.html", message = session['username']+" has successfully logged in!")
         else:
            #login authentication was called to access some confidential data
            print  "On redirect - next=", next
            return redirect(next)
      else:
	 # User has failed authentication
         msg = request.values.get('username')+" has failed authentication!"
         print "msg=", msg
         return render_template("result.html", message=msg)
  else:
     # GET method indicates request for initial login page
     if ('username' in session):
         # if some user is already logged in current session, then wait for logout first
        return render_template("result.html", message=session['username'] + " is already logged in. Log out and log in to proceed as different user.")
     else:
        # login form is waiting to be filled
        return render_template('login.html')

   
@app.route('/register', methods=['POST', 'GET'])
def register():
	if request.method=='POST':
                msg =  dbHandler.insertUser(request)
                print msg
		return render_template("result.html", message = msg);
	else:
		return render_template('register.html')

             
@app.route('/logout', methods=['POST', 'GET'])
def logout():
    if 'username' in session:
        name = session.pop('username')
        return render_template("result.html", message=name +" has logged out Successfully.")
    return render_template("result.html", message="You are already logged out.")


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' in session:
           return f(*args, **kwargs)
        else:
           print "Can not  access secret_page without logging in"
           print url_for('login', next = request.path)
           return redirect(url_for('login', next = request.path))
                           
    return decorated_function

@app.route('/secret_page')
@login_required
def secret_page():
    return render_template("result.html", message="You can see this confidential page only if you are logged in!!!!")

@app.route('/admin')
@login_required
def admin():
    #only admin is allowed see the users' details.
    if 'username' in session and session['username'] == 'admin':
       rows, message = dbHandler.getAll()
       print "rows are :", rows
       return render_template("showall.html", rows=rows)
    else:
       return redirect(url_for('login', next = request.path))



if __name__ == '__main__':
    app.config['SESSION_COOKIE_HTTPONLY']=False
    app.config['DEBUG'] = True
    app.run(debug=True, host='127.0.0.1')
    
#   app.run(debug=True, host='127.0.0.1', ssl_context=('cert.pem', 'key.pem'))
   

