import sqlite3 as sql

def insertUser(username,password):
    con = sql.connect("database.db")
    cur = con.cursor()
    cur.execute("INSERT INTO users (username,password) VALUES (?,?)", (username,password))
    con.commit()
    con.close()

def retrieveUsers():
	con = sql.connect("database.db")
	cur = con.cursor()
	cur.execute("SELECT username, password FROM users")
	users = cur.fetchall()
	con.close()
	return users
	
#https://www.techonthenet.com/sqlite/comments.php	
def authenticate(request):
    con = sql.connect("database.db")
    isDebug = request.form.get('debug',None)
    print "isDebug=", isDebug
    if isDebug and isDebug == "1":
        #request.session["username"] = "admin"
        #request.session["isAdmin"] = "True"
        loggedIn = "admin loggedIn Successfully"
        sqlQuery = "Running in debug Mode"
    else:
# authentication code follows
        username = request.form['username']
        password = request.form['password']
        sqlQuery = "select * from users where (username ='" + username + "' and password ='" + password + "')"
        cursor = con.cursor()
        cursor.execute(sqlQuery)
        row = cursor.fetchone()
        if row:
            loggedIn = username + " loggedIn Successfully"
        else:
            loggedIn = username + " Login Failure"
    return sqlQuery + "\r\n<br> Logged In Status: <strong>" + loggedIn + "</strong>"
