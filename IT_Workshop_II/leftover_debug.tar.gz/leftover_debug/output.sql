PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE users ( id integer PRIMARY KEY autoincrement, username TEXT NOT NULL, password TEXT NOT NULL);
INSERT INTO "users" VALUES(1,'guest','guest');
INSERT INTO "users" VALUES(2,'guest','guest');
INSERT INTO "users" VALUES(3,'rekha','singhal');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('users',3);
COMMIT;
