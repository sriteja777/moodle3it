view source code for login page and copy and paste it locally to hack.html.
uncomment debug field from hack.html and fix the form action url to point to absolute path of server you want to hack.
load hack.html and login with admin priviledges.
