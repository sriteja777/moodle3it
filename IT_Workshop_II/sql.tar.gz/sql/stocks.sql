
drop table if exists stocks;

BEGIN TRANSACTION;
CREATE TABLE stocks (date text, trans text, symbol text, qty real, price real);
INSERT INTO "stocks" VALUES('2006-01-05','BUY','AMZ',100.0,35.14);
INSERT INTO "stocks" VALUES('2006-03-28','BUY','IBM',1000.0,45.0);
INSERT INTO "stocks" VALUES('2006-04-05','BUY','MSOFT',1000.0,72.0);
INSERT INTO "stocks" VALUES('2006-04-06','SELL','IBM',500.0,53.0);
COMMIT;

SELECT * FROM stocks;
