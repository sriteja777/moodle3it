PRAGMA foreign_keys  = true;
drop table if exists stocks;
drop table if exists customers;

BEGIN TRANSACTION;

CREATE TABLE customers (
   custid integer PRIMARY KEY,
   name text,
   gender text,
   age integer);

INSERT INTO "customers" VALUES(1, 'Sam', 'M', 23 );
INSERT INTO "customers" VALUES(2, 'Bob', 'M', 34 );
INSERT INTO "customers" VALUES(3, 'Mary', 'F', 57 );

CREATE TABLE stocks (
   custid integer,
   date text,
   trans text,
   symbol text,
   qty real,
   price real,
   FOREIGN KEY(custid)
         REFERENCES customers(custid)
	     ON UPDATE CASCADE
	         ON DELETE CASCADE);
   
INSERT INTO "stocks" VALUES(1,'2006-01-05','BUY','AMZ',100.0,35.14);
INSERT INTO "stocks" VALUES(2,'2006-03-28','BUY','IBM',1000.0,45.0);
INSERT INTO "stocks" VALUES(2,'2006-04-05','BUY','MSOFT',1000.0,72.0);
INSERT INTO "stocks" VALUES(1,'2006-04-06','SELL','IBM',500.0,53.0);

SELECT * FROM stocks, customers where stocks.custid = customers.custid;


COMMIT;
