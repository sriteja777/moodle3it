import sqlite3

conn = sqlite3.connect('example.db')   
c = conn.cursor()

# Create table
c.execute('''create table stocks (date text, trans text, symbol text, qty real, price real)''')

# Insert a row of data
c.execute("""insert into stocks values ('2006-01-05','BUY','AMZ',100,35.14)""")

for t in (('2006-03-28', 'BUY', 'IBM', 1000, 45.00),

          ('2006-04-05', 'BUY', 'MSOFT', 1000, 72.00),

          ('2006-04-06', 'SELL', 'IBM', 500, 53.00),

         ):

    c.execute('insert into stocks values (?,?,?,?,?)', t)

# run a query to get all records
c.execute('select * from stocks')
for row in c.fetchall():
    print row

# run a query
c.execute('select * from stocks where symbol=?', ('AMZ',))
row = c.fetchone()
print "## checking investment on AMZ ##"
print row

conn.commit()
conn.close()
