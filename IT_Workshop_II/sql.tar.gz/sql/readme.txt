Command to create database from script
sqlite3 /tmp/database.db < stocks.sql
or
Command to initialize sql shell from script
sqlite3 -init  stocks.sql

1. stocks.sql - a file with SQL commands to create a simple table stocks

sqlite3 -init   no-primary-foreign.sql
2. no-primary-foreign.sql - SQL commands to create 2 tables with one
common column with no referential integrity constraints

sqlite3 -init   primary-foreign.sql
3. primary-foreign.sql - SQL commands to create 2 tables with one
common column with referential integrity constraints using primary and
foreign keys

sqlite3 -init    cascade-primary-foreign.sql
4. cascade-primary-foreign.sql - SQL commands to create 2 tables with one
common column with referential integrity constraints and cascading on
update and delete operationst on

sqlite3 -init join.sql 
5. join.sql - SQL commands to retrieve rows from two tables joined over a
common column

python sql.py
6. sql.py - python code with programmatic access to SQLite engine
