import sqlite3 as sql
SqlInjection = True

def insertUser(username,password):
    con = sql.connect("database.db")
    cur = con.cursor()
    cur.execute("INSERT INTO users (username,password) VALUES (?,?)", (username,password))
    con.commit()
    con.close()

def retrieveUsers():
	con = sql.connect("database.db")
	cur = con.cursor()
	cur.execute("SELECT username, password FROM users")
	users = cur.fetchall()
	con.close()
	return users
	
	
def authenticate(request):
    con = sql.connect("database.db")
    username = request.form['username']
    password = request.form['password']
    cursor = con.cursor()
    
    if SqlInjection == True:
       sqlQuery = "select * from users where username ='" + username + "' and password ='" + password + "';"
       print "sqlQuery=", sqlQuery
       cursor.execute(sqlQuery)
    else:
       sqlQuery = "select * from users where username = ? and password = ?";
       print "sqlQuery=", sqlQuery
       cursor.execute(sqlQuery, (username, password))
       
    rows = cursor.fetchall()
    s = ''
    if len(rows):
        loggedIn = username + " loggedIn Successfully"
        # display confidential information
        
        s += "<h2> <table border = 1 cellspacing=5 width=50% height=50px bgcolor=yellow>"
        for x in rows:
            s += "<tr>"
            for y in x:
               s += "<td>" + str(y) + "</td>"
            s += "</tr><br>"
        s += "</table></h2>"
        print s
    else:
        loggedIn = username + " Login Failure"
    return sqlQuery + "\r\n<br> Logged In Status: <strong>" + loggedIn + "</strong>" + s
